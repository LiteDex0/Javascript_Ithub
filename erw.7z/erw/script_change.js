const textElement = document.querySelector('.italic');

const textElementContent = textElement.innerHTML;
console.log(textElementContent);

textElement.innerHTML = "Легко и просто!"

